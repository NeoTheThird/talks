---
title: Public Key Cryptography
subtitle: Bachelorseminar "Ausgewählte Kapitel der Informatik"
author: Jan Sprinz
institute: LMU
date: 31.10.2019
theme: CambridgeUS
aspectratio: 169
bibliography: Cryptography.bib
---

# Cryptography

## $cryp \cdot tog \cdot ra \cdot phy$

>"Practice of the enciphering and deciphering of messages in secret code in order to render them unintelligible to all but the intended receiver."

[@encyclopedia_britannica_cryptography_2017]

# Motivation: Why encrypt anything?

![Communication between two parties, "Alice" and "Bob".](./img/alicebob.png){.class height=25%}

. . .

## Why Alice and Bob?

- Representing parties "A" and "B" in a transmission
- "Fictional characters commonly used as placeholder names in cryptology" [@wikipedia_alice_2019]
- First introduced by @rivest_method_1978

# Motivation: Why encrypt anything?

![Eavesdropping by a third party, "Eve", on the communication between two peers, "Alice" and "Bob". [cf. @wikipedia_alice_2019]](./img/alicebobeve.png){.class height=45%}

# Motivation: Why encrypt anything?

![Man-in-the-middle attack: A malicious third party, "Mallory", hijacks the communication between two peers, "Alice" and "Bob". [cf. @wikipedia_alice_2019]](./img/man-in-the-middle.png){.class height=45%}

# The secure system

## Requirements

1. **Confidentiality**: No unauthorized person should be able to read messages.

. . .

2. **Integrity**: No unauthorized party should be able to modify messages.

. . .

3. **Authenticity**: All parties need to be verifiable.

. . .

4. **Key Management**: The keys need to be securely created, stored, and distributed.

cf. @ernst_grundkurs_2016, 138

# Traditional cipher system

![Traditional cipher system for the secure transmission of a message $X$ using a key $k$ and an encryption algorithm $T$, as well as a decryption algorithm $T^{-1}$. Own graphic based on @dewdney_new_2001, 251](./img/traditional.png){.class width=90%}

. . .

## Example: caesar code

Replace each letter of the message with the *k*th letter after it [cf. @ernst_grundkurs_2016, 140].


# Traditional cipher system: Example: Caesar code

Example: $X =$ **SECRET**; $k = 4$

. . .

::: columns

:::: column

## Encryption $T = x_i \rightarrow x_{i + (k MOD n)}$

| $k=0$ | **S** | **E** | **C** | **R** | **E** | **T** |
|---|---|---|---|---|---|---|
| $k=1$ | T | F | D | S | F | U |
| $k=2$ | U | G | E | T | G | V |
| $k=3$ | V | H | F | U | H | W |
| $k=4$ | W | I | G | V | I | X |

::::

:::: column
. . .

## Decryption $T^{-1} = x_i \rightarrow x_{i - (k MOD n)}$

| $k=0$ | W | I | G | V | I | X |
|---|---|---|---|---|---|---|
| $k=1$ | V | H | F | U | H | W |
| $k=2$ | U | G | E | T | G | V |
| $k=3$ | T | F | D | S | F | U |
| $k=4$ | **S** | **E** | **C** | **R** | **E** | **T** |

::::

:::

# Limitations of traditional cipher systems

- The key needs to be known to all involved parties **and no one else** $\Rightarrow$ the key needs to be communicated over a secure channel

. . .

- The system does not scale

. . .

- The key is a single point of failure, and is stored in multiple locations

# Public Key Cryptography: Concept

![Public key cipher system. Own graphic based on @diffie_new_1976, 647](./img/publickey.png){.class width=95%}

# Usecase: Signing

!["Alice" encrypts a message with her private key $a$. Everyone receiving the message can verify its authenticity by decrypting it with her public key $a'$.](./img/signing.png){.class height=70%}

# Usecase: Secure communication

!["Alice" encrypts a message with Bob's public key $b'$. Only Bob can decrypt it with his private key $b$.](./img/securecomm.png){.class width=70%}

# Usecase: Signed secure communication

!["Alice" encrypts a message with her private key $a$ and Bob's public key $b'$. Bob can verify the authenticity of the message by decrypting with Alice's public key and $a'$ and his private key $b$.](./img/combined.png){.class height=70%}

# Requirements and challenges

::: columns

:::: column

## Computing private key $k$ and public key $k'$

- $k$ and $k'$ need to be easy to generate

. . .

- $k'$ must be easy to compute from $k$

. . .

-  $k$ must be difficult to compute from $k'$

cf. @dewdney_new_2001, 252

::::

. . .

:::: column

## Avoiding security by obscurity

*"The reader is urged to find a way to 'break' the system. Once the method has withstood all attacks for a sufficient length of time it may be used with a reasonable amount of confidence."*

[@rivest_method_1978, 126]

::::

:::

. . .

::: columns

:::: column

## Encryption is broken if...

- The private key is leaked

. . .

- The encryption system itself is cracked

cf. @dewdney_new_2001, 255

::::

:::: column

. . .

## Our cryptosystem is broken if...

- Our problem is not $NP$-complete

. . .

- Someone proves that $P == NP$

cf. @dewdney_new_2001, 255

::::

:::

# RSA

cf. @dewdney_new_2001, 255

## Underlying principle

- based on the factorization problem: find a non-trivial factor for an $n$-bit number

. . .

## In practice

- the keys are generated from two prime factors $p$ and $q$

. . .

- the product $n = pq$ becomes the first part of the public key

. . .

- second part of the public key: $e \begin{cases} 1 < e < \phi(n) \\ \text{coprime of } n \text{ and } \phi(n)\end{cases}$ with $\phi (n) = (p - 1)(q - 1)$

. . .

  - *coprimes*: set of integers that only share $1$ as a factor
 
. . .

- a message $m < n$ is encrypted using the following formula $c = m^e \text{ MOD } n$

. . .

- the private key is the integer $d: 1 = ed \text{ MOD } \phi (n)$

. . .

- the message can be decrypted by computing $c^d \text{ MOD } n = m$.

# RSA: Example: Generate key pair

1. Two prime numbers $p = 2$, $q = 7$

. . .

2. Calculate $n = pq = 2*7 = 14$

. . .

3. Calculate $\phi (n)$, the number of coprimes of $n$: $1, 3, 5, 9, 11, 13$

  . . .

  - $\phi (n) = \phi (14) = (p - 1)(q - 1) = (2 - 1)(7 - 1) = 6$

. . .

4. Calculate $e \begin{cases} 1 < e < \phi(n) \\ \text{coprime of } n \text{ and } \phi(n)\end{cases} \Rightarrow e = 5$

. . .

5. Choose $d: 1 = ed \text{ MOD } \phi (n)$, for example $11$

. . .

| **_p_** | **_q_** | **_d_** | **_e_** | **_n_** |
|---------|---------|---------|---------|---------|
| $2$     | $7$     | $11$    | $5$     | $14$    |

# RSA: Example: Encrypt and Decrypt

|   _p_   |   _q_   |   _d_   | **_e_** | **_n_** | _m_     | **_c_** |
|---------|---------|---------|---------|---------|---------|---------|
| $2$     | $7$     | $11$    | $5$     | $14$    | $C = 3$ | $E = 5$ |

::: columns

:::: column

## Encrypt

$$ c = m^e \text{ MOD } n$$

. . .

$$ c = 3^5 \text{ MOD } 14 = 5 = E$$

::::

:::: column

. . .

## Decrypt

$$ m = c^d \text{ MOD } n$$

. . .

$$ m = 5^{11} \text{ MOD } 14 = 3 = C$$


::::

:::

# RSA: Is it secure?

. . .

::: columns

:::: column

## No

- NP-completeness has never been proven, so there might highly efficient algorithms to solve the factorization problem

. . .

- Quantum computers allow for much more efficient factorization

. . .

- Computers are getting faster exponentially (*moore's law*), so brute-forcing the key becomes easier

::::

:::: column

. . .

## Yes

- There's an infinite number of primes, so bigger factors can be used

. . .

- Algorithms are still not efficient enough to make cracking encryption profitable

. . .

- Quantum computers are still very experimental

. . .

- In practice, bugs in implementations are a more likely attack vector

::::

:::

cf. @ernst_grundkurs_2016, 164

# Bibliography
